export class CollectionRepository{
 constructor(store,collection){this.store=store;this.collection=collection}
 async list(predicate=()=>true){const db=await this.store.read();return (db[this.collection]??[]).filter(predicate).map(x=>structuredClone(x))}
 async get(id){const db=await this.store.read();const x=(db[this.collection]??[]).find(x=>x.id===id);return x?structuredClone(x):null}
 async save(item){await this.store.update(db=>{db[this.collection]??=[];const i=db[this.collection].findIndex(x=>x.id===item.id);if(i>=0)db[this.collection][i]=structuredClone(item);else db[this.collection].push(structuredClone(item))});return structuredClone(item)}
 async remove(id){await this.store.update(db=>{db[this.collection]??=[];db[this.collection]=db[this.collection].filter(x=>x.id!==id)})}
 async count(predicate=()=>true){return (await this.list(predicate)).length}
}
export class ClientRepository extends CollectionRepository{constructor(s){super(s,'clients')}}
export class BrandRepository extends CollectionRepository{constructor(s){super(s,'brands')}listByClient(c){return this.list(x=>x.clientId===c)}getByClient(c,i){return this.get(i).then(x=>x?.clientId===c?x:null)}}
export class AccountRepository extends CollectionRepository{constructor(s){super(s,'accounts')}listByClient(c){return this.list(x=>x.clientId===c)}}
export class ContentRepository extends CollectionRepository{constructor(s){super(s,'content')}listByClient(c){return this.list(x=>x.clientId===c)}}
export class CampaignRepository extends CollectionRepository{constructor(s){super(s,'campaigns')}listByClient(c){return this.list(x=>x.clientId===c)}}
export class ScheduleRepository extends CollectionRepository{constructor(s){super(s,'schedules')}listByClient(c){return this.list(x=>x.clientId===c)}}
export class MetricRepository extends CollectionRepository{constructor(s){super(s,'metrics')}listByClient(c){return this.list(x=>x.clientId===c)}}
export class AutomationRepository extends CollectionRepository{constructor(s){super(s,'automations')}listByClient(c){return this.list(x=>x.clientId===c)}}
export class CollectionByClientRepository extends CollectionRepository{listByClient(c){return this.list(x=>x.clientId===c)}}
