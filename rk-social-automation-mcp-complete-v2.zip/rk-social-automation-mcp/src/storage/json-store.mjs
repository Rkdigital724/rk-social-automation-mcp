import {mkdir,readFile,rename,writeFile} from 'node:fs/promises';
import {dirname} from 'node:path';
export class JsonStore{
 constructor(file,initial){this.file=file;this.initial=structuredClone(initial);this.queue=Promise.resolve()}
 async read(){try{return await this.#readNow()}catch(e){if(e.code==='ENOENT'){await this.#writeNow(this.initial);return structuredClone(this.initial)}throw e}}
 async update(mutator){let result;this.queue=this.queue.then(async()=>{const db=await this.read();result=await mutator(db);await this.#writeNow(db)});await this.queue;return result}
 async #readNow(){const raw=await readFile(this.file,'utf8');const db=JSON.parse(raw);if(!db||typeof db!=='object'||Array.isArray(db))throw new Error('Persistent store must contain an object');return db}
 async #writeNow(db){await mkdir(dirname(this.file),{recursive:true,mode:0o700});const tmp=`${this.file}.${process.pid}.${Date.now()}.tmp`;await writeFile(tmp,JSON.stringify(db,null,2),{mode:0o600});await rename(tmp,this.file)}
}
