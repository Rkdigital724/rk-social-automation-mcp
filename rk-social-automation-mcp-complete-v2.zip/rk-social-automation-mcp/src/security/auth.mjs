import {timingSafeEqual} from 'node:crypto';
export class Authenticator{
 constructor(expected){if(typeof expected!=='string'||expected.length<32||/replace-with|change-me/i.test(expected))throw new Error('RK_SOCIAL_AUTH_TOKEN must be a strong token of at least 32 characters');this.expected=Buffer.from(expected)}
 authenticate(token){if(typeof token!=='string'||!token)throw new Error('Authentication required');const b=Buffer.from(token);if(b.length!==this.expected.length||!timingSafeEqual(b,this.expected))throw new Error('Invalid authentication token');return{id:'local-principal',roles:['admin']}}
}
