import {createCipheriv,createDecipheriv,createHash,randomBytes} from 'node:crypto';
export class SecretVault{
 constructor(master){if(typeof master!=='string'||master.length<32)throw new Error('RK_SOCIAL_VAULT_KEY must be at least 32 characters');this.key=createHash('sha256').update(master).digest()}
 encrypt(value){const iv=randomBytes(12),c=createCipheriv('aes-256-gcm',this.key,iv),enc=Buffer.concat([c.update(String(value),'utf8'),c.final()]);return `${iv.toString('base64url')}.${c.getAuthTag().toString('base64url')}.${enc.toString('base64url')}`}
 decrypt(token){const [iv,tag,data]=String(token).split('.');if(!iv||!tag||!data)throw new Error('Invalid secret');const d=createDecipheriv('aes-256-gcm',this.key,Buffer.from(iv,'base64url'));d.setAuthTag(Buffer.from(tag,'base64url'));return Buffer.concat([d.update(Buffer.from(data,'base64url')),d.final()]).toString('utf8')}
}
