export class PermissionManager{can(principal,action){return Boolean(principal?.roles?.includes('admin'))&&['READ','WRITE','DESTRUCTIVE','SYSTEM','AUTOMATION'].includes(action)}}
