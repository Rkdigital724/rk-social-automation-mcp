const CAPS={facebook:{publishPost:true,readAnalytics:true},instagram:{publishPost:true,readAnalytics:true},linkedin:{publishPost:true,readAnalytics:true},x:{publishPost:true,readAnalytics:true},tiktok:{publishPost:true,readAnalytics:true},youtube:{publishPost:true,readAnalytics:true}};
export class BasePlatformAdapter{
 constructor(name){this.name=name}
 platform(){return this.name}
 capabilities(){return {connect:true,readProfile:false,...(CAPS[this.name]||{}),configured:false,dryRun:false}}
 async publishPost(){throw new Error(`${this.name} live adapter requires OAuth/API credentials and a configured integration`)}
 async analytics(){throw new Error(`${this.name} live analytics adapter requires OAuth/API credentials and a configured integration`)}
}
export class DryRunPlatformAdapter extends BasePlatformAdapter{
 capabilities(){return {...super.capabilities(),connect:false,publishPost:true,readAnalytics:true,configured:true,dryRun:true}}
 async publishPost(input){return {dryRun:true,platform:this.name,externalId:`dry_${Date.now()}`,publishedAt:new Date().toISOString(),input:{id:input.id,caption:input.caption,format:input.format}}}
 async analytics(){return {records:[]}}
}
export class WebhookPlatformAdapter extends BasePlatformAdapter{
 constructor(name,url,token){super(name);this.url=url;this.token=token}
 capabilities(){return {...super.capabilities(),configured:Boolean(this.url)}}
 async publishPost(input){if(!this.url)throw new Error(`${this.name} webhook is not configured`);const r=await fetch(this.url,{method:'POST',headers:{'content-type':'application/json',...(this.token?{authorization:`Bearer ${this.token}`}:{})},body:JSON.stringify({event:'publish',platform:this.name,post:{id:input.id,caption:input.caption,format:input.format,media:input.media??[]}})});if(!r.ok)throw new Error(`${this.name} publish webhook error ${r.status}`);const d=await r.json().catch(()=>({}));return {platform:this.name,externalId:d.externalId||d.id||`webhook_${Date.now()}`,response:d}}
}
export class PlatformRegistry{constructor(){this.adapters=new Map()}register(a){if(this.adapters.has(a.platform()))throw new Error(`Duplicate platform: ${a.platform()}`);this.adapters.set(a.platform(),a)}get(p){return this.adapters.get(p)||null}list(){return [...this.adapters.keys()]}describe(){return [...this.adapters.values()].map(a=>({platform:a.platform(),capabilities:a.capabilities()}))}}
