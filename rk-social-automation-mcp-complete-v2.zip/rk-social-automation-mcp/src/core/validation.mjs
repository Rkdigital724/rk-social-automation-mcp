export function assertObject(v){if(!v||typeof v!=='object'||Array.isArray(v))throw new Error('Input must be an object');return v}
export function string(v,field,{min=1,max=500}={}){if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)throw new Error(`Invalid ${field}`);return v.trim()}
export function optionalString(v,field,o={}){return v===undefined||v===null?undefined:string(v,field,o)}
export function idString(v,field){return string(v,field,{min:3,max:160}).replace(/[^a-zA-Z0-9_-]/g,()=>{throw new Error(`Invalid ${field}`)})}
export function arrayOfStrings(v,field,max=100){if(!Array.isArray(v)||v.length>max||v.some(x=>typeof x!=='string'||!x.trim()||x.length>2000))throw new Error(`Invalid ${field}`);return v.map(x=>x.trim())}
export const PLATFORMS=['facebook','instagram','linkedin','x','tiktok','youtube']
export function platform(v){if(!PLATFORMS.includes(v))throw new Error('Invalid platform');return v}
export function platforms(v){if(!Array.isArray(v)||v.length>PLATFORMS.length||v.some(x=>!PLATFORMS.includes(x)))throw new Error('Invalid platforms');return [...new Set(v)]}
export function enumValue(v,field,allowed){if(!allowed.includes(v))throw new Error(`Invalid ${field}`);return v}
export function isoFuture(v,field='runAt'){const t=Date.parse(string(v,field,{max:100}));if(!Number.isFinite(t)||t<=Date.now())throw new Error(`${field} must be a valid future timestamp`);return new Date(t).toISOString()}
