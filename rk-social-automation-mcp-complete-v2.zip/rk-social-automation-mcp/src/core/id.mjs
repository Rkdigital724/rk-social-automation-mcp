import { randomUUID } from 'node:crypto';
export function id(prefix='id'){return `${prefix}_${randomUUID()}`}
