export class Logger {
  constructor({level=process.env.RK_SOCIAL_LOG_LEVEL||'info'}={}){this.level=level}
  #write(level,message,meta={}){const rank={debug:10,info:20,warn:30,error:40};if(rank[level]<rank[this.level])return;process.stderr.write(JSON.stringify({ts:new Date().toISOString(),level,message,...meta})+'\n')}
  debug(m,x){this.#write('debug',m,x)} info(m,x){this.#write('info',m,x)} warn(m,x){this.#write('warn',m,x)} error(m,x){this.#write('error',m,x)}
}
