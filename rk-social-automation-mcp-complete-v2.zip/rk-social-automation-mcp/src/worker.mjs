import {buildRuntime} from './core/container.mjs';
const {scheduler,automationRunner}=buildRuntime();
async function once(){const now=new Date();const automation=await automationRunner.tick(now);const publishing=await scheduler.tick(now);if(automation.length||publishing.length)process.stdout.write(JSON.stringify({ts:now.toISOString(),automation,publishing})+'\n')}
await once();if(process.env.RK_SOCIAL_WORKER_LOOP==='true'){setInterval(()=>once().catch(e=>process.stderr.write((e.stack||e)+'\n')),Number(process.env.RK_SOCIAL_WORKER_INTERVAL_MS||30000))}
