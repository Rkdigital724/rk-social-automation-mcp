export class AIProvider{
 constructor({apiKey,baseUrl='https://api.openai.com/v1',model='gpt-5.6-mini',timeoutMs=45000}={}){this.apiKey=apiKey;this.baseUrl=baseUrl.replace(/\/$/,'');this.model=model;this.timeoutMs=timeoutMs}
 configured(){return Boolean(this.apiKey)}
 async generate({system,user,json=false}){
  if(!this.apiKey)throw new Error('AI provider is not configured');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),this.timeoutMs);
  try{const r=await fetch(`${this.baseUrl}/chat/completions`,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${this.apiKey}`},body:JSON.stringify({model:this.model,messages:[{role:'system',content:system},{role:'user',content:user}],temperature:0.7,...(json?{response_format:{type:'json_object'}}:{})}),signal:controller.signal});if(!r.ok)throw new Error(`AI provider error ${r.status}`);const d=await r.json();const text=d.choices?.[0]?.message?.content;if(!text)throw new Error('AI provider returned no content');return json?JSON.parse(text):text}finally{clearTimeout(timer)}
 }
}
