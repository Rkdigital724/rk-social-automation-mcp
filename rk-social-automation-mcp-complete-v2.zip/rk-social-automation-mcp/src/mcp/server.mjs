import {randomUUID} from 'node:crypto';
export class McpServer{
 constructor(registry,auth,permissions,limiter,logger){Object.assign(this,{registry,auth,permissions,limiter,logger})}
 async handle(raw){
  if(typeof raw!=='string'||Buffer.byteLength(raw,'utf8')>1_000_000)return this.error(null,-32600,'Invalid Request');
  let req;try{req=JSON.parse(raw)}catch{return this.error(null,-32700,'Parse error')}
  if(!req||typeof req!=='object'||Array.isArray(req)||req.jsonrpc!=='2.0'||typeof req.method!=='string')return this.error(req?.id??null,-32600,'Invalid Request');
  const id=req.id??null;
  try{
   if(req.method==='initialize')return this.result(id,{protocolVersion:'2025-06-18',serverInfo:{name:'rk-social-automation-mcp',version:'2.0.0'},capabilities:{tools:{listChanged:false}}});
   if(req.method==='ping')return this.result(id,{});
   if(req.method==='tools/list')return this.result(id,{tools:this.registry.list().map(t=>({name:t.name,description:t.description,inputSchema:t.inputSchema}))});
   if(req.method!=='tools/call')return this.error(id,-32601,'Method not found');
   const p=req.params;if(!p||typeof p!=='object'||Array.isArray(p)||typeof p.name!=='string')return this.error(id,-32602,'Invalid tools/call parameters');
   const principal=this.auth.authenticate(p.authToken);this.limiter.check(principal.id);const tool=this.registry.get(p.name);if(!tool)return this.error(id,-32602,`Unknown tool: ${p.name}`);if(!this.permissions.can(principal,tool.actionType))return this.error(id,-32003,'Permission denied');
   const structured=await tool.execute(p.arguments??{},{requestId:randomUUID(),principal});return this.result(id,{content:[{type:'text',text:JSON.stringify(structured)}],structuredContent:structured});
  }catch(e){const m=e instanceof Error?e.message:'Internal error';const c=/Authentication/i.test(m)?-32001:/Rate limit/i.test(m)?-32002:/Permission/i.test(m)?-32003:-32000;this.logger.warn('MCP request failed',{method:req.method,code:c});return this.error(id,c,m)}
 }
 result(id,result){return JSON.stringify({jsonrpc:'2.0',id,result})}error(id,code,message){return JSON.stringify({jsonrpc:'2.0',id,error:{code,message}})}
}
