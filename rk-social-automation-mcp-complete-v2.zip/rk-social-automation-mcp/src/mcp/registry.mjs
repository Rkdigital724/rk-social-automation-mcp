export class ToolRegistry{constructor(){this.tools=new Map()}register(tool){if(this.tools.has(tool.name))throw new Error(`Duplicate tool: ${tool.name}`);this.tools.set(tool.name,tool)}get(n){return this.tools.get(n)||null}list(){return [...this.tools.values()]}}
export class ModuleManager{constructor(registry){this.registry=registry}register(module){module.register(this.registry)}}
