# RK Social Automation MCP v2.0.0

Standalone RK Digital Social Media Automation MCP Agent. It is intentionally separate from the RK Web Development MCP, Google Ads Growth Agent, and Maintenance Agent.

## What is included

This release consolidates the nine planned phases into one production-oriented codebase:

1. Foundation & security
2. Brand and content intelligence
3. AI content generation
4. Creative brief / media planning
5. Calendar, approvals and scheduling
6. Publishing adapter layer + dry-run/webhook integrations
7. Analytics ingestion and summaries
8. AI/data-driven optimization
9. Autonomous recurring automation worker

## Core capabilities

- Multi-client workspaces with client isolation
- Rich brand profiles: voice, audience, pillars, rules, forbidden topics, competitors and CTAs
- Reusable social strategy generation
- AI-assisted content generation with deterministic fallback when AI is not configured
- Batch generation across platforms
- Content quality scoring
- Draft / approved / scheduled / published / rejected workflow
- Campaign management
- Creative briefs
- Encrypted social credentials at rest
- Platform abstraction for Facebook, Instagram, LinkedIn, X, TikTok and YouTube
- Safe dry-run publishing
- Configurable webhook publishing bridge per platform
- Scheduling worker
- Normalized analytics storage and summaries
- Optimization reports and recommendations
- Recurring automation rules for content generation and performance analysis
- MCP JSON-RPC server with tool discovery and authenticated tool execution
- Request size limits, rate limiting, validation, atomic persistence and structured logs

## Important live-integration note

The agent does not invent or hard-code platform credentials. Real platform publishing requires the relevant official platform app/OAuth setup and credentials. The adapter layer is ready for those integrations. For immediate end-to-end testing use `RK_SOCIAL_DRY_RUN=true`. A webhook bridge is also supported through per-platform environment variables.

## Run

Node.js 20+ is required.

```bash
cp .env.example .env
# set RK_SOCIAL_AUTH_TOKEN and RK_SOCIAL_VAULT_KEY to strong random secrets
npm test
npm run check
npm start
```

Worker:

```bash
npm run worker
```

Continuous worker:

```bash
npm run worker:loop
```

## Authentication

Every `tools/call` request must include `params.authToken`. The token must be at least 32 characters. Account access tokens and refresh tokens are encrypted with AES-256-GCM using `RK_SOCIAL_VAULT_KEY`.

## MCP request example

```json
{"jsonrpc":"2.0","id":1,"method":"tools/list"}
```

Tool calls use:

```json
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"get_system_status","authToken":"...","arguments":{}}}
```

## Worker model

The worker performs two independent loops:

- Automation runner: executes due recurring rules and creates drafts or optimization reports.
- Scheduler: publishes due approved posts through the configured platform adapter.

Human approval remains the default safety boundary: automation-generated content is created as `draft` and is not published unless approved and scheduled.

## Platform webhook bridge

For environments where a separate connector service owns official platform OAuth/API calls, configure:

- `RK_SOCIAL_FACEBOOK_WEBHOOK_URL`
- `RK_SOCIAL_INSTAGRAM_WEBHOOK_URL`
- `RK_SOCIAL_LINKEDIN_WEBHOOK_URL`
- `RK_SOCIAL_X_WEBHOOK_URL`
- `RK_SOCIAL_TIKTOK_WEBHOOK_URL`
- `RK_SOCIAL_YOUTUBE_WEBHOOK_URL`

Optional bearer tokens are available as `*_WEBHOOK_TOKEN` variants.

The webhook receives a small publish event containing platform and post metadata. It should return JSON with an `externalId` or `id` when available.

## Data

Default storage is `./data/social-agent.json`. The data directory is created with restrictive permissions and writes are atomic. For production, place the data directory on encrypted persistent storage and use a secret manager for environment secrets.

## Architecture

```text
                    RK Social Automation MCP
                              |
              +---------------+----------------+
              |               |                |
          Brand/Strategy   Content Engine   Automation
              |               |                |
              +---------------+----------------+
                              |
                     Approval / Calendar
                              |
                        Scheduler
                              |
                 Platform Adapter Layer
                  /  /  /  |  \  \  \
                 FB IG LI  X TikTok YT
                              |
                         Analytics
                              |
                         Optimization
```

## Safety boundary

The system is automation-capable, but it does not silently grant an AI unrestricted authority over external accounts. Publishing requires a connected account, an approved content item, a schedule or explicit publish action, and a configured adapter. Secrets are never returned by account listing tools.
