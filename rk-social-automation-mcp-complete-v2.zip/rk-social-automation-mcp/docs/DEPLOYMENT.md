# Deployment

## Minimum

- Node.js 20+
- Persistent writable data directory
- `RK_SOCIAL_AUTH_TOKEN` >= 32 characters
- `RK_SOCIAL_VAULT_KEY` >= 32 characters

## Recommended production setup

1. Run the MCP process under a dedicated OS user.
2. Store secrets outside source control.
3. Use encrypted persistent storage for `RK_SOCIAL_DATA_DIR`.
4. Run the worker as a separate supervised process.
5. Set `RK_SOCIAL_DRY_RUN=false` only after an adapter has been configured and tested.
6. Keep human approval enabled for generated content.
7. Send logs to centralized monitoring.
8. Back up the data file or replace the JSON store with a transactional database before high-volume multi-process deployment.

## Webhook connector model

The built-in webhook adapter lets an external connector service own official platform OAuth/API details. This keeps the Social Agent platform-independent while allowing real publishing once those connector credentials are configured.
