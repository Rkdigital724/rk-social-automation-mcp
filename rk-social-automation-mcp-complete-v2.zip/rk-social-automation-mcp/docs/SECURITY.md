# Security

- Strong startup secrets are mandatory.
- Tool calls are authenticated and permission checked.
- Requests larger than 1 MB are rejected.
- Rate limiting is applied per principal.
- Social account tokens are encrypted with AES-256-GCM.
- Secret fields are excluded from tool responses.
- Client boundaries are checked before cross-resource access.
- JSON persistence is serialized and atomically replaced.
- Generated content remains draft until explicit approval.
- Publishing only operates on approved content.
- Production deployments should use an external secret manager, encrypted storage and process isolation.
